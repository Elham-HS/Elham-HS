# TKT4108StructuralDynamics2
This repository contains Python code for examples and exercises in TKT4108 Structural Dynamics 2 at the Norwegian University of Science and Technology.
